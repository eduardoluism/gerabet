<?php
require_once '../includes/db.php';
require_once '../includes/config.php';
?>

<div class="sobre-nos">
<h3>Somente maiores de 18 anos</h3>
<p>A <?= $NomeSite ?> leva a sério a verificação da idade. Você tem de ter 18 anos ou mais para abrir conta conosco. Podemos solicitar informações para verificar sua idade e poderemos restringir ou suspender sua conta até que sua idade seja confirmada.
Certifique-se de inserir todos os seus dados corretamente.</p>
</div>